# Change-log


## v1.0.x

### Release v1.0.1 (4 November 2015)

* Licensed under Apache 2.0 license.

### Release v1.0.0 (28 July 2015)

* Initial version used operationally for experiments.
